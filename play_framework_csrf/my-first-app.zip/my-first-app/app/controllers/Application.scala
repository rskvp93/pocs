package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import play.filters.csrf._

case class UserData(name: String, age: Int)


object Global extends WithFilters(CSRFFilter()) with GlobalSettings {
  // ... onStart, onStop etc
}

class Application extends Controller {

  val userForm = Form(
    mapping(
      "name" -> nonEmptyText,
      "age" -> number(min = 0, max = 100))
      (UserData.apply)(UserData.unapply)
  )

  def index = CSRFAddToken { 
    Action {implicit request =>
      Ok(views.html.user(userForm))
      //Ok("token " + token)
    }
  }
  
  def submit = CSRFCheck {
    Action { implicit request =>
      userForm.bindFromRequest.fold(
        formWithErrors => BadRequest(views.html.user(formWithErrors)),
        userData => Ok("Hello " + userData.name + ", age " + userData.age)
      )
    }
  }

}
